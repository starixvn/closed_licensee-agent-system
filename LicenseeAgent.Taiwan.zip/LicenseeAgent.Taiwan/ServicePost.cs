﻿// ----------------------------------------------------------------------
// <copyright file="ServicePost.cs" company="Nexcel Solutions Vietnam">
//     Copyright (c) Nexcel Solutions Vietnam. All rights reserved.
// </copyright>
//
// ------------------------------------------------------------------------

namespace LicenseeAgent.Taiwan
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Web;
    using System.Runtime.Serialization.Json;
    using Fanex.Logging;
    using LicenseeAgent.Core.Configurations;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class ServicePost
    {
        /*public static T GetData<T>(string actionKey, IDictionary<string, string> actionParams)
        {
            var request = ServicePost.CreateRequest(actionKey);

            ServicePost.SetParams(request, actionParams);

            //string responseData = string.Empty;

            //using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            //{
            //    StreamReader reader = new StreamReader(response.GetResponseStream());
            //    responseData = reader.ReadToEnd();
            //}

            //return ServicePost.MakeRequest<T>(request);
        }*/

        static HttpWebRequest CreateRequest(string actionKey)
        {
            Uri address = new Uri(string.Format(ServiceSetting.UrlAction, AppSettings.TaiwanAPI, ServiceSetting.Actions[actionKey]));

            var request = WebRequest.Create(address) as HttpWebRequest;

            request.Method = ServiceSetting.Method;
            request.ContentType = ServiceSetting.ContentType;
            
            return request;
        }

        static void SetParams(HttpWebRequest request, IDictionary<string, string> actionParams)
        {
            StringBuilder paramData = new StringBuilder();

            foreach (var paramKey in actionParams.Keys)
            {
                paramData.Append(string.Format(ServiceSetting.ParamFormat, paramKey, HttpUtility.UrlEncode(actionParams[paramKey])));
            }

            byte[] formData = UTF8Encoding.UTF8.GetBytes(paramData.ToString());
            request.ContentLength = formData.Length;
            using (Stream post = request.GetRequestStream())
            {
                post.Write(formData, 0, formData.Length);
            }
        }

        static object MakeRequest(HttpWebRequest request)
        {
            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        throw new Exception(String.Format(ServiceSetting.HttpError, response.StatusCode, response.StatusDescription));
                    }
                        
                    //DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(T));

                    //return jsonSerializer.ReadObject(response.GetResponseStream());
                }
            }
            catch (Exception exception)
            {
                LogService.Error(exception.Message, exception);
            }

            return null;
        }
    }
}
