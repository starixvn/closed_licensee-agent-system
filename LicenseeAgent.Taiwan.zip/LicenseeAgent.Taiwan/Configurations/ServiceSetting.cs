﻿// ----------------------------------------------------------------------
// <copyright file="ServiceSetting.cs" company="Nexcel Solutions Vietnam">
//     Copyright (c) Nexcel Solutions Vietnam. All rights reserved.
// </copyright>
//
// ------------------------------------------------------------------------

namespace LicenseeAgent.Taiwan
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    internal class ServiceSetting
    {
        public static IDictionary<string, string> Actions = new Dictionary<string, string>
        {
            { "CheckUserName", "CheckUserName"},
            { "InsertNewMember", "InsertNewMember"},
            { "ResetPassword", "ResetPassword"},
            { "UpdateMemberInfo", "UpdateMemberInfo"},
            { "UpdateMemberStatus", "UpdateMemberStatus"},
            { "GetMemberInfo", "GetMemberInfo"},
            { "GetMemberInfoList", "GetMemberInfoList"}
        };

        public static string UrlAction = "{0}/{1}";

        public static string Method = "POST";

        public static string ContentType = "application/x-www-form-urlencoded";

        public static string ParamFormat = "{0}={1}&";

        public static string HttpError = "Server error (HTTP {0}: {1}).";
    }
}
